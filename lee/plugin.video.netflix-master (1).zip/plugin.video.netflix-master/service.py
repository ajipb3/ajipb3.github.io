# -*- coding: utf-8 -*-
# Author: asciidisco
# Module: service
# Created on: 13.01.2017
# License: MIT https://goo.gl/5bMj3H
"""Kodi plugin for Netflix (https://netflix.com)"""
from __future__ import absolute_import, division, unicode_literals

import sys

from resources.lib.run_service import run

run(sys.argv)
